﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Collections;


namespace A111223029_wk10_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        TcpListener Server;
        Socket Client;
        Thread Th_Svr;
        Thread Th_Clt;
        Hashtable HT=new Hashtable();

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = MyIP();
        }
        private string MyIP()
        {
            string hn = Dns.GetHostName();
            IPAddress[] ip = Dns.GetHostEntry(hn).AddressList; // 取得本機IP陣列
            foreach (IPAddress it in ip)
            {
                if (it.AddressFamily == AddressFamily.InterNetwork)
                {
                    return it.ToString(); // 如果是IPv4回傳此IP字串
                }
            }
            return ""; // 找不到合格IP回傳空字串
        }


        private void button1_Click_1(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false; // 忽略跨執行緒處理的錯誤
            Th_Svr = new Thread(ServerSub);
            Th_Svr.IsBackground = true;
            Th_Svr.Start();
            button1.Enabled = false; // 讓按鍵無法使用

        }
        private void ServerSub()
        {
            IPEndPoint EP = new IPEndPoint(IPAddress.Parse(textBox1.Text), int.Parse(textBox2.Text));
            Server = new TcpListener(EP); // 建立伺服端監聽器
            Server.Start(100); // 啟動監聽，設定最多連線數100人

            while (true)
            {
                Client = Server.AcceptSocket(); // 建立此客戶的連線物件
                Th_Clt = new Thread(Listen); // 建立監聽此客戶連線的執行緒
                Th_Clt.IsBackground = true;
                Th_Clt.Start();
            }
        }
        private void Listen()
        {
            Socket Sck = Client; // 複製Client通訊物件到Sck
            Thread Th = Th_Clt;

            while (true)
            {
                try
                {
                    byte[] B = new byte[1023]; // 建立接收資料用的陣列
                    int inLen = Sck.Receive(B); // 接收網路資訊
                    string Msg = Encoding.Default.GetString(B, 0, inLen); // 翻譯訊息
                    listBox2.Items.Add("(接收)" + Msg);

                    string Cmd = Msg.Substring(0, 1);
                    string Str = Msg.Substring(1);

                    switch (Cmd)
                    {
                        case "0": // 新使用者上線
                            if (listBox1.Items.IndexOf(Str) == -1)
                            {
                                HT.Add(Str, Sck);
                                listBox1.Items.Add(Str);
                                SendAll(OnlineList()); // 將目前上線人名單回傳
                            }
                            else
                            {
                                string reply = "D" + Str + "使用者名稱重複";
                                B = Encoding.Default.GetBytes(reply);
                                Sck.Send(B, 0, B.Length, SocketFlags.None);
                                listBox2.Items.Add("(傳送)" + reply);
                                Th.Abort();
                            }
                            break;
                        case "9": // 使用者下線
                            HT.Remove(Str);
                            listBox1.Items.Remove(Str);
                            SendAll(OnlineList());
                            Th.Abort();
                            break;
                        case "1": // 廣播訊息
                            SendAll(Msg);
                            break;
                        default:
                            string[] C = Str.Split('|');
                            SendTo(Cmd + C[0], C[1]); // 傳送私密訊息
                            break;
                    }
                }
                catch (Exception)
                {
                    // 忽略錯誤，通常是客戶端無預警關閉
                }
            }
        }

        private string OnlineList()
        {
            string L = "L";
            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                L += listBox1.Items[i];
                if (i < listBox1.Items.Count - 1)
                {
                    L += ",";
                }
            }
            return L;
        }

        private void SendTo(string Str, string User)
        {
            listBox2.Items.Add("(傳送)" + Str + ":" + User);
            byte[] B = Encoding.Default.GetBytes(Str);
            Socket Sck = (Socket)HT[User];
            Sck.Send(B, 0, B.Length, SocketFlags.None);
        }

        private void SendAll(string Str)
        {
            listBox2.Items.Add("(傳送)" + Str);
            byte[] B = Encoding.Default.GetBytes(Str);
            foreach (Socket s in HT.Values)
            {
                s.Send(B, 0, B.Length, SocketFlags.None);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.ExitThread(); // 關閉所有執行緒
        }
    }
}
