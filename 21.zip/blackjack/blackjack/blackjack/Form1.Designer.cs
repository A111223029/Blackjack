﻿namespace blackjack
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.opponentCard5 = new System.Windows.Forms.PictureBox();
            this.opponentCard4 = new System.Windows.Forms.PictureBox();
            this.opponentCard3 = new System.Windows.Forms.PictureBox();
            this.opponentCard2 = new System.Windows.Forms.PictureBox();
            this.opponentCard1 = new System.Windows.Forms.PictureBox();
            this.myCard5 = new System.Windows.Forms.PictureBox();
            this.myCard4 = new System.Windows.Forms.PictureBox();
            this.myCard3 = new System.Windows.Forms.PictureBox();
            this.myCard2 = new System.Windows.Forms.PictureBox();
            this.myCard1 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.opponentCard5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.opponentCard4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.opponentCard3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.opponentCard2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.opponentCard1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myCard5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myCard4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myCard3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myCard2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myCard1)).BeginInit();
            this.SuspendLayout();
            // 
            // opponentCard5
            // 
            this.opponentCard5.Location = new System.Drawing.Point(535, 339);
            this.opponentCard5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.opponentCard5.Name = "opponentCard5";
            this.opponentCard5.Size = new System.Drawing.Size(125, 166);
            this.opponentCard5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.opponentCard5.TabIndex = 68;
            this.opponentCard5.TabStop = false;
            // 
            // opponentCard4
            // 
            this.opponentCard4.Location = new System.Drawing.Point(404, 339);
            this.opponentCard4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.opponentCard4.Name = "opponentCard4";
            this.opponentCard4.Size = new System.Drawing.Size(125, 166);
            this.opponentCard4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.opponentCard4.TabIndex = 67;
            this.opponentCard4.TabStop = false;
            // 
            // opponentCard3
            // 
            this.opponentCard3.Location = new System.Drawing.Point(271, 339);
            this.opponentCard3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.opponentCard3.Name = "opponentCard3";
            this.opponentCard3.Size = new System.Drawing.Size(125, 166);
            this.opponentCard3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.opponentCard3.TabIndex = 66;
            this.opponentCard3.TabStop = false;
            // 
            // opponentCard2
            // 
            this.opponentCard2.Location = new System.Drawing.Point(140, 339);
            this.opponentCard2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.opponentCard2.Name = "opponentCard2";
            this.opponentCard2.Size = new System.Drawing.Size(125, 166);
            this.opponentCard2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.opponentCard2.TabIndex = 65;
            this.opponentCard2.TabStop = false;
            // 
            // opponentCard1
            // 
            this.opponentCard1.Location = new System.Drawing.Point(9, 339);
            this.opponentCard1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.opponentCard1.Name = "opponentCard1";
            this.opponentCard1.Size = new System.Drawing.Size(125, 166);
            this.opponentCard1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.opponentCard1.TabIndex = 64;
            this.opponentCard1.TabStop = false;
            // 
            // myCard5
            // 
            this.myCard5.Location = new System.Drawing.Point(535, 39);
            this.myCard5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.myCard5.Name = "myCard5";
            this.myCard5.Size = new System.Drawing.Size(125, 166);
            this.myCard5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.myCard5.TabIndex = 63;
            this.myCard5.TabStop = false;
            // 
            // myCard4
            // 
            this.myCard4.Location = new System.Drawing.Point(404, 39);
            this.myCard4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.myCard4.Name = "myCard4";
            this.myCard4.Size = new System.Drawing.Size(125, 166);
            this.myCard4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.myCard4.TabIndex = 62;
            this.myCard4.TabStop = false;
            // 
            // myCard3
            // 
            this.myCard3.Location = new System.Drawing.Point(271, 39);
            this.myCard3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.myCard3.Name = "myCard3";
            this.myCard3.Size = new System.Drawing.Size(125, 166);
            this.myCard3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.myCard3.TabIndex = 61;
            this.myCard3.TabStop = false;
            // 
            // myCard2
            // 
            this.myCard2.Location = new System.Drawing.Point(140, 39);
            this.myCard2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.myCard2.Name = "myCard2";
            this.myCard2.Size = new System.Drawing.Size(125, 166);
            this.myCard2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.myCard2.TabIndex = 60;
            this.myCard2.TabStop = false;
            // 
            // myCard1
            // 
            this.myCard1.Location = new System.Drawing.Point(9, 39);
            this.myCard1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.myCard1.Name = "myCard1";
            this.myCard1.Size = new System.Drawing.Size(125, 166);
            this.myCard1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.myCard1.TabIndex = 59;
            this.myCard1.TabStop = false;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button2.Location = new System.Drawing.Point(776, 651);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(201, 40);
            this.button2.TabIndex = 58;
            this.button2.Text = "邀請玩家";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox4.Location = new System.Drawing.Point(777, 612);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(200, 31);
            this.textBox4.TabIndex = 57;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(773, 589);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 20);
            this.label5.TabIndex = 56;
            this.label5.Text = "系統訊息";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(773, 251);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 20);
            this.label8.TabIndex = 55;
            this.label8.Text = "線上使用者";
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Location = new System.Drawing.Point(777, 276);
            this.listBox1.Margin = new System.Windows.Forms.Padding(4);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(200, 304);
            this.listBox1.TabIndex = 54;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox3.Location = new System.Drawing.Point(777, 168);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(200, 31);
            this.textBox3.TabIndex = 53;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(773, 144);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 20);
            this.label9.TabIndex = 52;
            this.label9.Text = "玩家名稱";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox2.Location = new System.Drawing.Point(777, 101);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(200, 31);
            this.textBox2.TabIndex = 51;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.Location = new System.Drawing.Point(773, 78);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(99, 20);
            this.label10.TabIndex = 50;
            this.label10.Text = "伺服器Port";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox1.Location = new System.Drawing.Point(777, 41);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(200, 31);
            this.textBox1.TabIndex = 49;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.Location = new System.Drawing.Point(777, 206);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(201, 40);
            this.button1.TabIndex = 48;
            this.button1.Text = "登入伺服器";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.Location = new System.Drawing.Point(773, 16);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 20);
            this.label11.TabIndex = 47;
            this.label11.Text = "伺服器IP";
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button3.Location = new System.Drawing.Point(776, 696);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(201, 40);
            this.button3.TabIndex = 46;
            this.button3.Text = "重新開始";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button5.Location = new System.Drawing.Point(368, 649);
            this.button5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(109, 36);
            this.button5.TabIndex = 45;
            this.button5.Text = "停止";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button4.Location = new System.Drawing.Point(217, 649);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(109, 36);
            this.button4.TabIndex = 44;
            this.button4.Text = "加牌";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(5, 536);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 20);
            this.label3.TabIndex = 43;
            this.label3.Text = "對方點數：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(5, 314);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 20);
            this.label4.TabIndex = 42;
            this.label4.Text = "對方手牌：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(5, 236);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 20);
            this.label2.TabIndex = 41;
            this.label2.Text = "我方點數：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(5, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 20);
            this.label1.TabIndex = 40;
            this.label1.Text = "我方手牌：";
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button6.Location = new System.Drawing.Point(551, 649);
            this.button6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(109, 36);
            this.button6.TabIndex = 69;
            this.button6.Text = "發牌";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 740);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.opponentCard5);
            this.Controls.Add(this.opponentCard4);
            this.Controls.Add(this.opponentCard3);
            this.Controls.Add(this.opponentCard2);
            this.Controls.Add(this.opponentCard1);
            this.Controls.Add(this.myCard5);
            this.Controls.Add(this.myCard4);
            this.Controls.Add(this.myCard3);
            this.Controls.Add(this.myCard2);
            this.Controls.Add(this.myCard1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "21點遊戲";
            ((System.ComponentModel.ISupportInitialize)(this.opponentCard5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.opponentCard4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.opponentCard3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.opponentCard2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.opponentCard1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myCard5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myCard4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myCard3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myCard2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myCard1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox opponentCard5;
        private System.Windows.Forms.PictureBox opponentCard4;
        private System.Windows.Forms.PictureBox opponentCard3;
        private System.Windows.Forms.PictureBox opponentCard2;
        private System.Windows.Forms.PictureBox opponentCard1;
        private System.Windows.Forms.PictureBox myCard5;
        private System.Windows.Forms.PictureBox myCard4;
        private System.Windows.Forms.PictureBox myCard3;
        private System.Windows.Forms.PictureBox myCard2;
        private System.Windows.Forms.PictureBox myCard1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button6;
    }
}

