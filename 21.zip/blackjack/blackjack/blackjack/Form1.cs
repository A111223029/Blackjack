﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace blackjack
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            button4.Enabled = false; // 加牌按鈕
            button5.Enabled = false; // 停止按鈕
            button6.Enabled = false;  // 發牌按鈕
        }

        Socket T; // 通訊物件
        Thread Th; // 網路監聽執行緒
        string User; // 使用者名稱
        Random random = new Random();
        List<int> myHand = new List<int>(); // 我的手牌
        List<int> opponentHand = new List<int>(); // 對手手牌
        int myScore = 0; // 我的點數
        int opponentScore = 0; // 對手點數

        // 發送訊息
        private void Send(string Str)
        {
            byte[] B = Encoding.Default.GetBytes(Str);
            T.Send(B, 0, B.Length, SocketFlags.None);
        }

        // 接收並處理訊息
        private void Listen()
        {
            EndPoint ServerEP = (EndPoint)T.RemoteEndPoint;
            byte[] B = new byte[1023];
            int inLen = 0;
            string Msg, St, Str;

            while (true)
            {
                try
                {
                    inLen = T.ReceiveFrom(B, ref ServerEP);
                }
                catch (Exception)
                {
                    T.Close();
                    listBox1.Items.Clear();
                    MessageBox.Show("伺服器斷線了!");
                    button4.Enabled = true; // 啟用加牌按鈕
                    Th.Abort();
                }
                Msg = Encoding.Default.GetString(B, 0, inLen);
                St = Msg.Substring(0, 1);
                Str = Msg.Substring(1);

                switch (St)
                {
                    case "L": // 更新線上名單
                        listBox1.Items.Clear();
                        string[] M = Str.Split(',');
                        foreach (var item in M)
                            listBox1.Items.Add(item);
                        break;

                    case "C": // 收到卡牌訊息
                        string[] data = Str.Split('|');
                        opponentHand = data[0].Split(',').Select(int.Parse).ToList();
                        opponentScore = int.Parse(data[1]);
                        UpdateOpponentCards();
                        break;

                    case "5": // 邀請重玩
                        DialogResult result = MessageBox.Show("是否重玩21點遊戲?", "重玩訊息", MessageBoxButtons.YesNo);
                        Send(result == DialogResult.Yes ? "P" + "Y" : "P" + "N");
                        if (result == DialogResult.Yes) { ResetGame(); }
                        else
                        {
                            ResetGame();
                            listBox1.Enabled = true; //把線上名單打開
                            button2.Enabled = true; //把邀請玩家打開
                        }
                        break;

                    case "P": // 接收重玩訊息
                        if (Str == "Y")
                        {
                            MessageBox.Show("對方同意重玩，遊戲將重新開始！");
                            ResetGame(); // 重置遊戲狀態
                        }
                        else
                        {
                            MessageBox.Show("對方拒絕重玩！");
                            listBox1.Enabled = true; //把線上名單打開
                            button2.Enabled = true; //把邀請玩家打開
                        }
                        break;
                    case "I": //邀請的訊息
                        string[] F = Str.Split(',');
                        DialogResult res = MessageBox.Show(F[0] + "邀請玩21點遊戲,是否接受?", "邀請訊息", MessageBoxButtons.YesNo);

                        if (res == DialogResult.Yes)
                        {
                            int i = listBox1.Items.IndexOf(F[0]);
                            listBox1.SetSelected(i, true); //把邀請對象標註為選取
                            listBox1.Enabled = false; //把線上名單鎖住                            
                            button3.Enabled = true;

                            Send("R" + "Y" + "|" + F[0]); //把同意邀請的訊息回傳
                        }
                        else
                        {
                            Send("R" + "N" + "|" + F[0]); //把不同意邀請的訊息回傳
                            listBox1.Enabled = true; //把線上名單打開
                            button2.Enabled = true; //把邀請玩家打開
                        }
                        break;

                    case "R": //回覆邀請的訊息
                        if (Str == "Y") //同意邀請
                        {
                            MessageBox.Show(listBox1.SelectedItem.ToString() + "接受你的邀請,可以開始遊戲");
                            listBox1.Enabled = false;
                            button2.Enabled = false;
                            button1.Enabled = false;
                            button3.Enabled = true;

                            // 啟用發牌按鈕，禁用其他按鈕
                            button6.Enabled = true;  // 發牌按鈕
                            button4.Enabled = false; // 加牌按鈕
                            button5.Enabled = false; // 停止按鈕
                        }
                        else //拒絕邀請
                        {
                            MessageBox.Show("抱歉!" + listBox1.SelectedItem.ToString() + "拒絕你的邀請!");
                            listBox1.Enabled = true; //把線上名單打開
                            button2.Enabled = true; //把邀請玩家打開
                        }
                        break;
                    case "D": // 收到發牌訊息
                        Console.WriteLine(Str);

                        string[] dealData = Str.Split('|');

                        Console.WriteLine(dealData);

                        myHand = dealData[0].Split(',').Select(int.Parse).ToList();
                        myScore = int.Parse(dealData[1]);
                        opponentHand = dealData[2].Split(',').Select(int.Parse).ToList();
                        opponentScore = int.Parse(dealData[3]);

                        // 更新畫面
                        UpdateMyCards();
                        UpdateOpponentCards();

                        MessageBox.Show("對方已發牌，遊戲開始！");
                        break;
                    case "N": // 收到命名重複訊息                        
                        MessageBox.Show("名字重複了！");
                        textBox4.Text = "無法連上伺服器!" + "\r\n";
                        // 更新畫面
                        UpdateMyCards();
                        UpdateOpponentCards();
                        button1.Enabled = true;
                        break;
                    case "Z":
                        if (listBox1.Enabled) {
                            listBox1.Enabled = true;
                            button2.Enabled = true;
                        }
                        break;
                }
            }
        }

        // 發牌
        private void DealCard(bool isMyTurn)
        {
            int card = random.Next(1, 14); 
            // 隨機抽取 1 到 13 的數字 (1: A, 11: J, 12: Q, 13: K)
            if (card == 1) // 如果抽到 A
            {
                // 預設將 A 視為 1，後續根據分數可以改為 10
                card = 1;
            }
            else if (card > 10) // 如果是 J, Q, K，都當作 10 點
            {
                card = 10;
            }
            if (isMyTurn)
            {
                myHand.Add(card); // 加入玩家手牌
                myScore += card;  // 更新玩家分數
                UpdateMyCards();  // 更新畫面顯示
                if (myScore > 21) EndGame(false); // 如果超過21，結束遊戲
            }
            else
            {
                opponentHand.Add(card); // 加入對手手牌
                opponentScore += card;  // 更新對手分數
                UpdateOpponentCards();  // 更新對手畫面
            }
        }

        // 更新我的手牌顯示
        private void UpdateMyCards()
        {
            label2.Text = $"我的點數: {myScore}"; // 顯示當前分數
            for (int i = 1; i <= 5; i++)
            {
                if (i <= myHand.Count) // 確保顯示每張手牌
                {
                    if (myHand[i - 1] == 1)
                    {
                        Controls[$"myCard{i}"].Text = "A"; // 顯示 A
                    }
                    else
                    {
                        Controls[$"myCard{i}"].Text = myHand[i - 1].ToString(); // 顯示其他牌
                        PictureBox tmp = this.Controls.Find($"myCard{i}", false).FirstOrDefault() as PictureBox;
                        tmp.Image = Image.FromFile("./Resources/方塊" + myHand[i - 1].ToString() + ".png");
                    }
                }
                else
                {
                    Controls[$"myCard{i}"].Text = ""; // 清空顯示框
                }
            }
        }

        // 更新對手手牌顯示
        private void UpdateOpponentCards()
        {
            label3.Text = $"對方點數: {opponentScore}"; // 顯示對方分數
            for (int i = 1; i <= 5; i++)
            {
                if (i <= opponentHand.Count) // 確保顯示每張手牌
                {
                    if (opponentHand[i - 1] == 1)
                    {
                        Controls[$"opponentCard{i}"].Text = "A"; // 顯示 A
                    }
                    else
                    {
                        Controls[$"opponentCard{i}"].Text = opponentHand[i - 1].ToString(); // 顯示其他牌
                        PictureBox tmp = this.Controls.Find($"opponentCard{i}", false).FirstOrDefault() as PictureBox;
                        tmp.Image = Image.FromFile("./Resources/方塊"+ opponentHand[i - 1].ToString()+".png");
                    }
                }
                else
                {
                    Controls[$"opponentCard{i}"].Text = ""; // 清空顯示框
                }
            }
        }

        // 計算最終分數，處理 A 作為 1 或 10
        private int CalculateFinalScore(List<int> hand)
        {
            int score = hand.Sum();
            int aceCount = hand.Count(card => card == 1); // 計算手牌中 A 的數量

            // 如果分數 <= 11 且有 A，則將 A 當作 10
            while (score <= 11 && aceCount > 0)
            {
                score += 10;
                aceCount--;
            }

            return score;
        }

        // 重置遊戲
        private void ResetGame()
        {
            for (int i = 1; i <= 5; i++) {
                PictureBox tmp = this.Controls.Find($"myCard{i}", false).FirstOrDefault() as PictureBox;
                tmp.Image = null;
                tmp = this.Controls.Find($"opponentCard{i}", false).FirstOrDefault() as PictureBox;
                tmp.Image = null;
            }
            // 清空手牌
            myHand.Clear();
            opponentHand.Clear();

            // 重置分數
            myScore = 0;
            opponentScore = 0;

            // 更新畫面
            UpdateMyCards();
            UpdateOpponentCards();

            // 啟用發牌按鈕，禁用其他按鈕
            button6.Enabled = true;  // 發牌按鈕
            button4.Enabled = false; // 加牌按鈕
            button5.Enabled = false; // 停止按鈕

            MessageBox.Show("遊戲已重置，請點擊發牌按鈕開始新的一局！");
        }

        // 遊戲結束
        private void EndGame(bool isMyWin)
        {
            myScore = CalculateFinalScore(myHand);
            opponentScore = CalculateFinalScore(opponentHand);

            string result = isMyWin ? "你贏了!" : "你輸了!";
            MessageBox.Show(result, "遊戲結束");
            // 遊戲結束後不重置遊戲，改為等待玩家按下重新開始按鈕
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                if (listBox1.SelectedItem.ToString() != User)
                {
                    Send("I" + User + "|" + listBox1.SelectedItem);
                }
                else
                {
                    MessageBox.Show("不可以邀請自己!");
                }
            }
            else
            {
                MessageBox.Show("沒有選取邀請的對象!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
            {
                Send("5" + "|" + listBox1.SelectedItem);
            }
            ResetGame();
            string message = $"G|{listBox1.SelectedItem.ToString()}";
            Send(message);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            User = textBox3.Text;
            string IP = textBox1.Text;
            int Port = int.Parse(textBox2.Text);
            try
            {
                IPEndPoint EP = new IPEndPoint(IPAddress.Parse(IP), Port);
                T = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                T.Connect(EP);
                Th = new Thread(Listen);
                Th.IsBackground = true;
                Th.Start();
                textBox4.Text = "已連線伺服器!" + "\r\n"; Send("0" + User);
                button1.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
            }
            catch
            {
                textBox4.Text = "無法連上伺服器!" + "\r\n";
            }
        }

        private void CheckGameResult()
        {
            // 判定爆掉
            if (myScore > 21)
            {
                EndGame(false); // 玩家爆掉，遊戲結束

                // 玩家爆掉，按鈕關閉
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                return;
            }
            if (opponentScore > 21)
            {
                EndGame(true); // 對手爆掉，玩家獲勝

                // 對手爆掉，按鈕關閉
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                return;
            }

            // 判定遊戲結束的結果
            if (myScore > opponentScore)
            {
                EndGame(true); // 玩家贏
            }
            else if (myScore < opponentScore)
            {
                EndGame(false); // 玩家輸
            }
            else
            {
                MessageBox.Show("平手！", "遊戲結束");
                ResetGame(); // 遊戲重置
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DealCard(true); // 玩家加牌
            string message = $"D|{listBox1.SelectedItem.ToString()}|{string.Join(",", myHand)}|{myScore}|{string.Join(",", opponentHand)}|{opponentScore}";
            Send(message); // 傳送玩家手牌與點數
            
            CheckGameResult(); // 檢查遊戲結果

            // 更新畫面
            UpdateMyCards();
            UpdateOpponentCards();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            while (opponentScore < 17) DealCard(false); // 對手加牌直到 >= 17
            CheckGameResult(); // 檢查遊戲結果
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // 發兩張牌給玩家與對手
            for (int i = 0; i < 2; i++)
            {
                DealCard(true); // 玩家
                DealCard(false); // 對手
            }

            // 傳送發牌資訊給對方
            string message = $"D|{listBox1.SelectedItem.ToString()}|{string.Join(",", myHand)}|{myScore}|{string.Join(",", opponentHand)}|{opponentScore}";
            Send(message);

            // 更新畫面
            UpdateMyCards();
            UpdateOpponentCards();

            // 停用發牌按鈕，啟用其他按鈕
            button6.Enabled = false; // 發牌按鈕只能用一次
            button4.Enabled = true;  // 加牌按鈕
            button5.Enabled = true;  // 停止按鈕
        }
        // 關閉程式
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            // Code
            try
            {
                Send($"Z|{User}");
            }
            catch (Exception)
            {

            }
        }        
    }
}