﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Blackjack
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Socket T; // 通訊物件
        Thread Th; // 網路監聽執行緒
        string User; // 使用者
        Random random = new Random();
        List<int> myHand = new List<int>(); // 我的手牌
        List<int> opponentHand = new List<int>(); // 對手手牌
        int myScore = 0;
        int opponentScore = 0;

        
        private void Send(string Str)
        {
            byte[] B = Encoding.Default.GetBytes(Str);
            T.Send(B, 0, B.Length, SocketFlags.None);
        }

        private void Listen()
        {
            EndPoint ServerEP = (EndPoint)T.RemoteEndPoint;
            byte[] B = new byte[1023];
            int inLen = 0;
            string Msg, St, Str;
            while (true)
            {
                try
                {
                    inLen = T.ReceiveFrom(B, ref ServerEP);
                }
                catch (Exception)
                {
                    T.Close();
                    listBox1.Items.Clear();
                    MessageBox.Show("伺服器斷線了!");
                    button4.Enabled = true;
                    Th.Abort();
                }
                Msg = Encoding.Default.GetString(B, 0, inLen);
                St = Msg.Substring(0, 1);
                Str = Msg.Substring(1);
                switch (St)
                {
                    case "L":
                        listBox1.Items.Clear();
                        string[] M = Str.Split(',');
                        for (int i = 0; i < M.Length; i++) listBox1.Items.Add(M[i]);
                        break;
                    case "5":
                        DialogResult result = MessageBox.Show("是否重玩21點遊戲?", "重玩訊息", MessageBoxButtons.YesNo);
                        if (result == DialogResult.Yes)
                        {

                            Send("P" + "Y" + "|" + listBox1.SelectedItem);
                            Random rnd = new Random();
                        }
                        else
                        {
                            Send("P" + "N" + "|" + listBox1.SelectedItem);
                        }
                        break;
                    case "P":
                        if (Str == "Y")
                        {
                            MessageBox.Show(listBox1.SelectedItem.ToString() + "接受你的邀請,可以開始重玩遊戲");
                            Random rnd = new Random();
                            int[] mark = new int[25];

                            button5.Enabled = false;
                            button3.Enabled = true;
                        }
                        else
                        {
                            MessageBox.Show("抱歉!" + listBox1.SelectedItem.ToString() + "拒絕你的邀請!");
                        }
                        break;

                    case "D":
                        textBox4.Text = Str;
                        button4.Enabled = true;
                        button5.Enabled = false;
                        T.Close();
                        Th.Abort();
                        break;
                    case "I": //邀請的訊息
                        string[] F = Str.Split(',');
                        DialogResult res = MessageBox.Show(F[0] + "邀請玩21點遊戲,是否接受?", "邀請訊息", MessageBoxButtons.YesNo);

                        if (res == DialogResult.Yes)
                        {
                            int i = listBox1.Items.IndexOf(F[0]);
                            listBox1.SetSelected(i, true); //把邀請對象標註為選取
                            listBox1.Enabled = false; //把線上名單鎖住                            
                            button3.Enabled = true;

                            Send("R" + "Y" + "|" + F[0]); //把同意邀請的訊息回傳
                        }
                        else
                        {
                            Send("R" + "N" + "|" + F[0]); //把不同意邀請的訊息回傳
                        }
                        break;

                    case "R": //回覆邀請的訊息
                        if (Str == "Y") //同意邀請
                        {
                            MessageBox.Show(listBox1.SelectedItem.ToString() + "接受你的邀請,可以開始遊戲");
                            listBox1.Enabled = false;
                            button5.Enabled = false;
                            button3.Enabled = true;
                        }
                        else //拒絕邀請
                        {
                            MessageBox.Show("抱歉!" + listBox1.SelectedItem.ToString() + "拒絕你的邀請!");
                        }
                        break;

                    case "C": // 抽牌
                        int card = int.Parse(Str);
                        opponentHand.Add(card);
                        opponentScore = CalculateScore(opponentHand);
                        DisplayOpponentCards();
                        break;

                    case "S": // 停牌
                        MessageBox.Show("對手停止加牌！");
                        CheckWinner();
                        break;


                }
            }

            
        }

        private void button4_Click(object sender, EventArgs e)//邀請玩家
        {
            if (listBox1.SelectedIndex != -1)
            {
                if (listBox1.SelectedItem.ToString() != User)
                {
                    Send("I" + User + "|" + listBox1.SelectedItem);
                }
                else
                {
                    MessageBox.Show("不可以邀請自己!");
                }
            }
            else
            {
                MessageBox.Show("沒有選取邀請的對象!");
            }
        }

        private void button3_Click(object sender, EventArgs e)//重新開始
        {
            if (listBox1.SelectedIndex >= 0)
            {
                Send("5" + "|" + listBox1.SelectedItem);
            }
        }

        private int CalculateScore(List<int> hand)
        {
            int score = 0;
            int aceCount = 0;

            foreach (int card in hand)
            {
                int value = (card - 1) % 13 + 1;
                if (value == 1) aceCount++;
                score += value > 10 ? 10 : value;
            }

            while (score <= 11 && aceCount > 0)
            {
                score += 10;
                aceCount--;
            }

            return score;
        }

        private int DrawCard()// 抽一張牌
        {
            return random.Next(1, 53); // 撲克牌 1-52
        }
        private string GetCardImageName(int card)
        {
            string[] suits = { "方塊", "紅心", "黑桃", "梅花" };
            int suitIndex = (card - 1) / 13;
            int rank = (card - 1) % 13 + 1;
            return $"{suits[suitIndex]}{rank}";
        }

        private void CheckWinner()
        {
            if (myScore > 21)
            {
                MessageBox.Show("你爆牌了！對手獲勝！");
            }
            else if (opponentScore > 21 || myScore > opponentScore)
            {
                MessageBox.Show("你獲勝了！");
            }
            else if (myScore < opponentScore)
            {
                MessageBox.Show("對手獲勝！");
            }
            else
            {
                MessageBox.Show("平手！");
            }

            button5.Enabled = true;
            listBox1.Enabled = true;
        }
        private void DisplayMyCards()// 顯示我的牌
        {
            for (int i = 0; i < myHand.Count; i++)
            {
                string cardName = $"card{myHand[i]}.png";
                PictureBox pic = this.Controls.Find($"picMyCard{i + 1}", true)[0] as PictureBox;
                pic.Image = (Image)Properties.Resources.ResourceManager.GetObject(cardName);
            }
        }

        private void DisplayOpponentCards()// 顯示對手牌
        {
            for (int i = 0; i < opponentHand.Count; i++)
            {
                string cardName = $"card{opponentHand[i]}.png";
                PictureBox pic = this.Controls.Find($"picOpponentCard{i + 1}", true)[0] as PictureBox;
                pic.Image = (Image)Properties.Resources.ResourceManager.GetObject(cardName);
            }


        }


        private void button3_Click_1(object sender, EventArgs e)//重新開始
        {
            if (listBox1.SelectedIndex >= 0)
            {
                Send("5" + "|" + listBox1.SelectedItem);
            }
        }

        
        private void button1_Click_1(object sender, EventArgs e)//連接伺服器
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            User = textBox3.Text;
            string IP = textBox1.Text;
            int Port = int.Parse(textBox2.Text);
            try
            {
                IPEndPoint EP = new IPEndPoint(IPAddress.Parse(IP), Port);
                T = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                T.Connect(EP);
                Th = new Thread(Listen);
                Th.IsBackground = true;
                Th.Start();
                textBox4.Text = "已連線伺服器!" + "\r\n"; Send("0" + User);
                button1.Enabled = false;
                button4.Enabled = true;
                button5.Enabled = true;
            }
            catch
            {
                textBox4.Text = "無法連上伺服器!" + "\r\n";
            }
        }

        private void button2_Click_1(object sender, EventArgs e)//邀請玩家
        {
            if (listBox1.SelectedIndex != -1)
            {
                if (listBox1.SelectedItem.ToString() != User)
                {
                    Send("I" + User + "|" + listBox1.SelectedItem);
                }
                else
                {
                    MessageBox.Show("不可以邀請自己!");
                }
            }
            else
            {
                MessageBox.Show("沒有選取邀請的對象!");
            }
        }

        private void button4_Click_1(object sender, EventArgs e)//加牌
        {
            int card = DrawCard();
            myHand.Add(card);
            myScore = CalculateScore(myHand);
            DisplayMyCards();
            Send("C" + card);

            if (myScore > 21)
            {
                MessageBox.Show("你爆牌了！");
                button5.PerformClick();
            }
        }

        private void button5_Click(object sender, EventArgs e)//停止加牌
        {
            Send("S");
            CheckWinner();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (button1.Enabled == false) // 檢查連線按鈕是否被禁用
            {
                Send("9" + User); // 傳送自己的離線訊息給伺服器
                T.Close(); // 關閉網路通訊
            }
        }
    }
}
